package com.finalProject.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Homecontroller {
	@RequestMapping(value = { "/", "/homepage" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("homepage");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/newseatselect1" }, method = RequestMethod.GET)
	public ModelAndView hello1(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("newseatselect1");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/flightdetail" }, method = RequestMethod.GET)
	public ModelAndView hello2(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("flightdetail");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/Seatselection" }, method = RequestMethod.GET)
	public ModelAndView hello3(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Seatselection");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/SeatBook" }, method = RequestMethod.GET)
	public ModelAndView hello4(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("SeatBook");
		return mv;
	}
	
	
	@RequestMapping(value = { "/", "/Payment" }, method = RequestMethod.GET)
	public ModelAndView hello5(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Payment");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/Login" }, method = RequestMethod.GET)
	public ModelAndView hello6(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Login");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/allFlightList" }, method = RequestMethod.GET)
	public ModelAndView hello7(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addPassenger");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/Passenger" }, method = RequestMethod.GET)
	public ModelAndView hello8(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Passenger");
		return mv;
	}
	
	@RequestMapping(value = { "/", "/Ticket" }, method = RequestMethod.GET)
	public ModelAndView hello19(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Ticket");
		return mv;
	}
}
