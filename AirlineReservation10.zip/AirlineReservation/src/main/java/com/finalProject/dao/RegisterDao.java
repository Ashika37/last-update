package com.finalProject.dao;

import com.finalProject.entity.Register;

public interface RegisterDao {
	public Boolean saveUser(Register register);
}
