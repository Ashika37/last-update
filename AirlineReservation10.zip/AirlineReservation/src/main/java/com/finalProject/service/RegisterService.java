package com.finalProject.service;

import com.finalProject.entity.Register;

public interface RegisterService {
	public boolean saveUser(Register register);
}